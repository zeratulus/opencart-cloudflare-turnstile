<?php
// Text
$_['error_captcha'] = 'Patvirtinimas nepavyko! Bandykite dar kartą.';

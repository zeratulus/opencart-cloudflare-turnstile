<?php
// Text
$_['error_captcha'] = 'Theip ar an bhfíorú! Bain triail as arís le do thoil.';

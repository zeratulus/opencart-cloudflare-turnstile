<?php
// Text
$_['error_captcha'] = '¡La verificación falló! Inténtalo de nuevo.';

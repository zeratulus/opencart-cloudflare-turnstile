<?php
// Text
$_['error_captcha'] = 'Verificatie mislukt! Probeer het opnieuw.';

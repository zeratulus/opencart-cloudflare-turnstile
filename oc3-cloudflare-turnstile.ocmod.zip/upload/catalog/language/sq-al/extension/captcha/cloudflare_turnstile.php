<?php
// Text
$_['error_captcha'] = 'Verifikimi dështoi! Ju lutemi provoni përsëri.';

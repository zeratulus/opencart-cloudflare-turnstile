<?php
// Text
$_['error_captcha'] = 'Verifica non riuscita! Per favore riprova.';

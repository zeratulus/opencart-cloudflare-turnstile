<?php
// Text
$_['error_captcha'] = 'Verificarea a eșuat! Vă rugăm să încercați din nou.';

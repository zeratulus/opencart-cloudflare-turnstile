<?php
// Text
$_['error_captcha'] = 'Verifikācija neizdevās! Lūdzu, mēģiniet vēlreiz.';

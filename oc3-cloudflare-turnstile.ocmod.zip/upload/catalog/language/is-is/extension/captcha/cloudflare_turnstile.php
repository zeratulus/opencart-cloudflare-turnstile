<?php
// Text
$_['error_captcha'] = 'Staðfesting mistókst! Vinsamlegast reyndu aftur.';

<?php
// Text
$_['error_captcha'] = 'Verification failed! Please try again.';

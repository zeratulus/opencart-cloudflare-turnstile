<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Udvidelser';
$_['text_success']     = 'Succes: Du har ændret Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Rediger Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Webstedsnøgle';
$_['entry_secret_key'] = 'Hemmelig nøgle';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tilladelse til at ændre Cloudflare Turnstile Captcha!';

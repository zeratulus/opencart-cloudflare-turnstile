<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Estensjonijiet';
$_['text_success']     = 'Suċċess: Inti mmodifikajt Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Editja Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ċavetta tas-Sit';
$_['entry_secret_key'] = 'Ċavetta Sigrieta';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Twissija: M\'għandekx permess timmodifika Cloudflare Turnstile Captcha!';

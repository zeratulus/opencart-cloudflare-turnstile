<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Пашырэнні';
$_['text_success']     = 'Поспех: вы змянілі Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Рэдагаваць Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ключ сайта';
$_['entry_secret_key'] = 'Сакрэтны ключ';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Папярэджанне: у вас няма дазволу на змяненне Cloudflare Turnstile Captcha!';

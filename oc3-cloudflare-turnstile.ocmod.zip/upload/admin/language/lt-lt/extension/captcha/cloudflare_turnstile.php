<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Plėtiniai';
$_['text_success']     = 'Sėkmė: Jūs modifikavote Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Redaguoti Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Svetainės raktas';
$_['entry_secret_key'] = 'Slaptas raktas';
$_['entry_status']     = 'Būsena';

// Error
$_['error_permission'] = 'Įspėjimas: Jūs neturite leidimo modifikuoti Cloudflare Turnstile Captcha!';

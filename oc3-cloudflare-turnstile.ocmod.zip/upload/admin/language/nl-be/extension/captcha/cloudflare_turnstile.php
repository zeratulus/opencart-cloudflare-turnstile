<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Succes: U heeft Cloudflare Turnstile Captcha gewijzigd!';
$_['text_edit']        = 'Cloudflare Turnstile Captcha bewerken';

// Entry
$_['entry_site_key']   = 'Sleutel van de site';
$_['entry_secret_key'] = 'Geheime sleutel';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Waarschuwing: u heeft geen toestemming om Cloudflare Turnstile Captcha te wijzigen!';

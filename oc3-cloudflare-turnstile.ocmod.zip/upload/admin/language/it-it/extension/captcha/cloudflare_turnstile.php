<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Estensioni';
$_['text_success']     = 'Successo: hai modificato Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Modifica Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Chiave del sito';
$_['entry_secret_key'] = 'Chiave segreta';
$_['entry_status']     = 'Stato';

// Error
$_['error_permission'] = 'Attenzione: non hai il permesso di modificare Cloudflare Turnstile Captcha!';

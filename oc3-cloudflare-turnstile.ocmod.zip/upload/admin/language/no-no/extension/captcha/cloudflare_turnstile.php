<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Utvidelser';
$_['text_success']     = 'Suksess: Du har endret Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Rediger Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Nettstedsnøkkel';
$_['entry_secret_key'] = 'Hemmelig nøkkel';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Advarsel: Du har ikke tillatelse til å endre Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Налаштування Cloudflare Turnstile Captcha успішно змінено!';
$_['text_edit']        = 'Редагувати Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ключ сайту (Site Key)';
$_['entry_secret_key'] = 'Секретний ключ (Secret Key)';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас немає прав для зміни налаштувань Cloudflare Turnstile Captcha!';

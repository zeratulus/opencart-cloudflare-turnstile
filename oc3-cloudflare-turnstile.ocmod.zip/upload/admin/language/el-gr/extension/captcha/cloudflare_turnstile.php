<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Επεκτάσεις';
$_['text_success']     = 'Επιτυχία: Έχετε τροποποιήσει το Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Επεξεργασία Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Κλειδί ιστότοπου';
$_['entry_secret_key'] = 'Μυστικό κλειδί';
$_['entry_status']     = 'Κατάσταση';

// Error
$_['error_permission'] = 'Προειδοποίηση: Δεν έχετε άδεια να τροποποιήσετε το Cloudflare Turnstile Captcha!';

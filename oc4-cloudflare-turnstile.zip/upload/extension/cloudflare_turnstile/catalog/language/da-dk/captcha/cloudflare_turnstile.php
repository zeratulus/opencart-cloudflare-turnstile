<?php
// Text
$_['error_captcha'] = 'Bekræftelse mislykkedes! Prøv venligst igen.';

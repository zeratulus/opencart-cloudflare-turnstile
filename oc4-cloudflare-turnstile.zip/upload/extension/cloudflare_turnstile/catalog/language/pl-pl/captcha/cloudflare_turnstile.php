<?php
// Text
$_['error_captcha'] = 'Weryfikacja nie powiodła się! Proszę spróbuj ponownie.';

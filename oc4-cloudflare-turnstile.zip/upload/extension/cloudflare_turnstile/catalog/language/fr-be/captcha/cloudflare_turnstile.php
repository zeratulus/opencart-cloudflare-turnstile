<?php
// Text
$_['error_captcha'] = 'La vérification a échoué ! Veuillez réessayer.';

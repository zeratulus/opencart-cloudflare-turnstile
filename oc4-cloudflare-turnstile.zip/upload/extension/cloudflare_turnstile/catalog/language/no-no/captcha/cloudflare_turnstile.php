<?php
// Text
$_['error_captcha'] = 'Bekreftelse mislyktes! Prøv igjen.';

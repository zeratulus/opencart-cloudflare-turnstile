<?php
// Text
$_['error_captcha'] = 'Verifizierung fehlgeschlagen! Bitte versuchen Sie es erneut.';

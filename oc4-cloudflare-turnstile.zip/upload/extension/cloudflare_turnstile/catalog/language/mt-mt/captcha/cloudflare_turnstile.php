<?php
// Text
$_['error_captcha'] = 'Verifika falliet! Jekk jogħġbok erġa\' pprova.';

<?php
// Text
$_['error_captcha'] = 'Kinnitamine ebaõnnestus! Palun proovi uuesti.';

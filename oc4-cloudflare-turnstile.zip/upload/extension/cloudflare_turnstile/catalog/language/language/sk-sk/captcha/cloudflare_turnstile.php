<?php
// Text
$_['error_captcha'] = 'Overenie zlyhalo! Prosím skúste znova.';

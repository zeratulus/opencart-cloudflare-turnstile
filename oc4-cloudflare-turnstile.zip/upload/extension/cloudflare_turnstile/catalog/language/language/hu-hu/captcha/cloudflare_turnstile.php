<?php
// Text
$_['error_captcha'] = 'Az ellenőrzés sikertelen! Kérjük, próbálja újra.';

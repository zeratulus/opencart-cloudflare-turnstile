<?php
// Text
$_['error_captcha'] = 'A verificação falhou! Por favor, tente novamente.';

<?php
// Text
$_['error_captcha'] = 'Verifikacija nije uspela! Molimo pokušajte ponovo.';

<?php
// Text
$_['error_captcha'] = 'Ověření se nezdařilo! Prosím zkuste to znovu.';

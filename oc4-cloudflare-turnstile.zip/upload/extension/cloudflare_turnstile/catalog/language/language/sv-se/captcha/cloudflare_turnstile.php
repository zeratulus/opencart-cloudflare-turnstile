<?php
// Text
$_['error_captcha'] = 'Verifieringen misslyckades! Försök igen.';

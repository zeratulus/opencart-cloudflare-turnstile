<?php
// Text
$_['error_captcha'] = 'Preverjanje ni uspelo! Prosim poskusite ponovno.';

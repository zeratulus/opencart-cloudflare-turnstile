<?php
// Text
$_['error_captcha'] = 'Verifikacija nije uspjela! Molimo pokušajte ponovo.';

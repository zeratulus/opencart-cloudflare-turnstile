<?php
// Text
$_['error_captcha'] = 'Vahvistus epäonnistui! Yritä uudelleen.';

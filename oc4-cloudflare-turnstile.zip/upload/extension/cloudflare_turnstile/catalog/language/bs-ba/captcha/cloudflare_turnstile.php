<?php
// Text
$_['error_captcha'] = 'Provjera nije uspjela! Molimo pokušajte ponovo.';

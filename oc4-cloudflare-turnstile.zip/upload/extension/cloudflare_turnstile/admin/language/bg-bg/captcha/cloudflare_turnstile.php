<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Успех: Вие променихте Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Редактиране на Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ключ на сайта';
$_['entry_secret_key'] = 'Таен ключ';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате разрешение да променяте Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Síntí';
$_['text_success']     = 'Rath: D\'athraigh tú Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Cuir Cloudflare Turnstile Captcha in eagar';

// Entry
$_['entry_site_key']   = 'Eochair an tSuímh';
$_['entry_secret_key'] = 'Eochair Rúnda';
$_['entry_status']     = 'Stádas';

// Error
$_['error_permission'] = 'Rabhadh: Níl cead agat Cloudflare Turnstile Captcha a mhodhnú!';

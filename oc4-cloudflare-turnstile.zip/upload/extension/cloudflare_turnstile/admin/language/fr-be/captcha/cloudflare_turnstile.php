<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès : vous avez modifié Cloudflare Turnstile Captcha !';
$_['text_edit']        = 'Modifier Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Clé du site';
$_['entry_secret_key'] = 'Clé secrète';
$_['entry_status']     = 'Statut';

// Error
$_['error_permission'] = 'Attention : vous n\'avez pas la permission de modifier Cloudflare Turnstile Captcha !';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Viðbætur';
$_['text_success']     = 'Árangur: Þú hefur breytt Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Breyta Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Vefsvæðislykill';
$_['entry_secret_key'] = 'Leyndarmál';
$_['entry_status']     = 'Staða';

// Error
$_['error_permission'] = 'Viðvörun: Þú hefur ekki leyfi til að breyta Cloudflare Turnstile Captcha!';

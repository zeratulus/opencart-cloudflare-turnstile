<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Extensiones';
$_['text_success']     = 'Éxito: ¡Ha modificado Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Editar Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Clave del sitio';
$_['entry_secret_key'] = 'Clave secreta';
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Advertencia: ¡No tiene permiso para modificar Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolg: Sie haben das Cloudflare Turnstile Captcha geändert!';
$_['text_edit']        = 'Cloudflare Turnstile Captcha bearbeiten';

// Entry
$_['entry_site_key']   = 'Site-Schlüssel';
$_['entry_secret_key'] = 'Geheimer Schlüssel';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, das Cloudflare Turnstile Captcha zu ändern!';

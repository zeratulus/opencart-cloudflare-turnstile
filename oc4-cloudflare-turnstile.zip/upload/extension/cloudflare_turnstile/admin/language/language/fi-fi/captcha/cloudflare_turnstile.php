<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Laajennukset';
$_['text_success']     = 'Onnistui: Olet muokannut Cloudflare Turnstile Captchaa!';
$_['text_edit']        = 'Muokkaa Cloudflare Turnstile Captchaa';

// Entry
$_['entry_site_key']   = 'Sivuston avain';
$_['entry_secret_key'] = 'Salainen avain';
$_['entry_status']     = 'Tila';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole lupaa muokata Cloudflare Turnstile Captchaa!';

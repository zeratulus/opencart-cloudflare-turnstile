<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Extensii';
$_['text_success']     = 'Succes: Ați modificat Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Editare Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Cheia site-ului';
$_['entry_secret_key'] = 'Cheie secretă';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atenție: Nu aveți permisiunea de a modifica Cloudflare Turnstile Captcha!';

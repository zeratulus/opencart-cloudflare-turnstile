<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Tillägg';
$_['text_success']     = 'Klart: Du har ändrat Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Ändra Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Webbplatsnyckel';
$_['entry_secret_key'] = 'Hemlig nyckel';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Varning: Du har inte behörighet att ändra Cloudflare Turnstile Captcha!';

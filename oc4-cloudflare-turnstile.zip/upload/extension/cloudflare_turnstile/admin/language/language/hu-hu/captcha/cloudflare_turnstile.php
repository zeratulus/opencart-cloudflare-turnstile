<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Módosította a Cloudflare Turnstile Captcha-t!';
$_['text_edit']        = 'Cloudflare Turnstile Captcha szerkesztése';

// Entry
$_['entry_site_key']   = 'Webhelykulcs';
$_['entry_secret_key'] = 'Titkos kulcs';
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelmeztetés: Nincs engedélye a Cloudflare Turnstile Captcha módosítására!';

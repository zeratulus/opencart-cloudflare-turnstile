<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Razširitve';
$_['text_success']     = 'Uspeh: Spremenili ste Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Uredi Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ključ spletnega mesta';
$_['entry_secret_key'] = 'Skrivni ključ';
$_['entry_status']     = 'Stanje';

// Error
$_['error_permission'] = 'Opozorilo: Nimate dovoljenja za spreminjanje Cloudflare Turnstile Captcha!';

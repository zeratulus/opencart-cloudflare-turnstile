<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Proširenja';
$_['text_success']     = 'Uspješno: Izmijenili ste Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Uredi Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ključ web-lokacije';
$_['entry_secret_key'] = 'Tajni ključ';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Upozorenje: Nemate dopuštenje za izmjenu Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Успіх: ви змінили Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Редагувати Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ключ сайту';
$_['entry_secret_key'] = 'Секретний ключ';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Попередження: у вас немає дозволу на зміну Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Sucesso: Você modificou o Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Editar Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Chave do site';
$_['entry_secret_key'] = 'Chave secreta';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Aviso: Você não tem permissão para modificar o Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Rozšírenia';
$_['text_success']     = 'Úspech: Zmenili ste Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Upraviť Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Kľúč stránky';
$_['entry_secret_key'] = 'Tajný kľúč';
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornenie: Nemáte oprávnenie na zmenu Cloudflare Turnstile Captcha!';

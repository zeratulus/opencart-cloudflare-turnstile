<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Ekstenzije';
$_['text_success']     = 'Uspešno: Izmenili ste Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Uredi Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Ključ sajta';
$_['entry_secret_key'] = 'Tajni ključ';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Upozorenje: Nemate dozvolu da izmenite Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Rozšíření';
$_['text_success']     = 'Úspěch: Změnili jste Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Upravit Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Klíč webu';
$_['entry_secret_key'] = 'Tajný klíč';
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Upozornění: Nemáte oprávnění ke změně Cloudflare Turnstile Captcha!';

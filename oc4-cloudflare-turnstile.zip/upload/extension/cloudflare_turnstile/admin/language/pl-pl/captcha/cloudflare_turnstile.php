<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Rozszerzenia';
$_['text_success']     = 'Sukces: Zmodyfikowałeś Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Edytuj Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Klucz witryny';
$_['entry_secret_key'] = 'Tajny klucz';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Ostrzeżenie: Nie masz uprawnień do modyfikowania Cloudflare Turnstile Captcha!';

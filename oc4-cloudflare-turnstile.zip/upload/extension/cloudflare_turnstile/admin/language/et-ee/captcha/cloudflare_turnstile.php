<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Laiendused';
$_['text_success']     = 'Edu: olete muutnud Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Redigeeri Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Saidi võti';
$_['entry_secret_key'] = 'Salajane võti';
$_['entry_status']     = 'Olek';

// Error
$_['error_permission'] = 'Hoiatus: teil pole luba Cloudflare Turnstile Captcha muutmiseks!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Paplašinājumi';
$_['text_success']     = 'Veiksmīgi: Jūs esat modificējis Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Rediģēt Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Vietnes atslēga';
$_['entry_secret_key'] = 'Slepenā atslēga';
$_['entry_status']     = 'Statuss';

// Error
$_['error_permission'] = 'Brīdinājums: Jums nav atļaujas modificēt Cloudflare Turnstile Captcha!';

<?php
// Heading
$_['heading_title']    = 'Cloudflare Turnstile Captcha';

// Text
$_['text_extension']   = 'Zgjerimet';
$_['text_success']     = 'Sukses: Ju keni modifikuar Cloudflare Turnstile Captcha!';
$_['text_edit']        = 'Modifiko Cloudflare Turnstile Captcha';

// Entry
$_['entry_site_key']   = 'Çelësi i faqes';
$_['entry_secret_key'] = 'Çelësi sekret';
$_['entry_status']     = 'Statusi';

// Error
$_['error_permission'] = 'Paralajmërim: Ju nuk keni leje për të modifikuar Cloudflare Turnstile Captcha!';
